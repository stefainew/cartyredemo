import React from 'react';

const Testimonials: React.FC = () => {
  const reviews = [
    {
      text: '"Изключително бързо обслужване. Смениха гумите ми за 20 минути, докато пиех кафе. Перфектен баланс!"',
      name: 'Иван П.',
      service: 'Смяна на гуми',
    },
    {
      text: '"Дойдох без записан час за лепене на гума и ме приеха веднага. Майсторите са много любезни и си разбират от работата."',
      name: 'Десислава М.',
      service: 'Ремонт и лепене',
    },
    {
      text: '"Най-доброто място в София за изправяне на джанти. Машините им са нови, а диагностиката е много точна."',
      name: 'Николай Т.',
      service: 'Джанти и диагностика',
    },
  ];

  return (
    <section id="reviews" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-5xl font-black uppercase tracking-tighter text-secondary">
            Какво казват клиентите
          </h2>
          <div className="w-20 h-1.5 bg-primary mx-auto mt-4"></div>
        </div>

        <div className="flex gap-8 overflow-x-auto pb-12 snap-x no-scrollbar">
          {reviews.map((review, idx) => (
            <div
              key={idx}
              className="flex-none w-full md:w-[400px] snap-center bg-slate-50 p-10 relative"
            >
              <span className="material-symbols-outlined text-slate-200 text-6xl absolute top-6 right-6">
                format_quote
              </span>
              <div className="flex gap-1 mb-4">
                {[1, 2, 3, 4, 5].map((s) => (
                  <span
                    key={s}
                    className="material-symbols-outlined text-yellow-500 fill-1"
                    style={{ fontVariationSettings: "'FILL' 1" }}
                  >
                    star
                  </span>
                ))}
              </div>
              <p className="text-lg text-slate-700 italic mb-8">{review.text}</p>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-bold text-secondary text-lg">{review.name}</h4>
                  <span className="bg-primary/10 text-primary text-[10px] font-black uppercase px-2 py-1 rounded">
                    {review.service}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-8">
          <button className="inline-flex items-center gap-2 font-bold text-secondary border-b-2 border-primary pb-1 hover:text-primary transition-colors uppercase tracking-widest">
            Виж всички ревюта
            <span className="material-symbols-outlined text-sm">arrow_forward</span>
          </button>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;